package com.perficient.role.service;

import java.util.List;

import com.perficient.role.entity.RoleStatus;

public interface RoleStatusService {

	List<RoleStatus> findAll();

	RoleStatus create(RoleStatus projResource);
}
