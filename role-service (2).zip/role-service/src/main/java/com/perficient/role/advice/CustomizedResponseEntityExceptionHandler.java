package com.perficient.role.advice;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.perficient.role.exception.ErrorDetails;
import com.perficient.role.exception.RoleNotFoundException;

@ControllerAdvice(basePackageClasses = com.perficient.role.web.api.RoleController.class)
public class CustomizedResponseEntityExceptionHandler {

	@ExceptionHandler(
			RoleNotFoundException.class)
	public final ResponseEntity<ErrorDetails> handleNotFoundException(RoleNotFoundException ex) {
		ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), "");
		return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	}
}
