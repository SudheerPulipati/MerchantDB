package com.perficient.role.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.perficient.role.entity.Role;
import com.perficient.role.repository.RoleRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Transactional
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleRepository roleRepository;


//	@Autowired
//	public RoleServiceImpl(RoleRepository roleRepository, RoleSearchPredicateBuilder roleSearchPredicateBuilder) {
//		this.roleRepository = roleRepository;
//		this.roleSearchPredicateBuilder = roleSearchPredicateBuilder;
//	}

	@Override
	public List<Role> findAllRoles() {

		// Predicate filter = roleSearchPredicateBuilder.createPredicate(roleSearch);
		// Pageable pageable = PageRequest.of(roleSearch.getPageNumber(),
		// roleSearch.getSize(),
		// Sort.by(Order.by("roleTitle")));
		//
		// Page<Role> page = roleRepository.findAll(filter, pageable);
		//
		// if (page == null) {
		// return new PageDto<RoleResource>(null, 0, 0);
		// }

		return roleRepository.findAll();

	}

	// @Override
	// public Optional<RoleResource> findById(Long id) {
	// Optional<Role> op = roleRepository.findById(id);
	//
	// Optional<RoleResource> out = Optional.empty();
	//
	// if (op.isPresent()) {
	// out = Optional.of(roleMapper.fromRole(op.get()));
	// }
	//
	// return out;
	// }

	@Override
	public Role create(Role resource) {

		return (roleRepository.save(resource));
	}

	// @Override
	// public RoleResource update(RoleResource resource) {
	//
	// Optional<Role> op = roleRepository.findById(resource.getId());
	//
	// if (op.isPresent()) {
	//
	// Role p = roleMapper.updateRole(resource);
	//
	// return roleMapper.fromRole(roleRepository.save(p));
	// } else {
	// log.error("unable to update role with id {}, it does not exist in db.",
	// resource.getId());
	// throw new EntityNotFoundException("unable to update role");
	// }
	//
	// }

	// @Override
	// public void delete(Long id) {
	//
	// roleRepository.deleteById(id);
	//
	// }

	@Override
	public Optional<Role> findById(String id) {
		return roleRepository.findById(id);
	}

	@Override
	public Role update(Role resource) {
		return roleRepository.save(resource);
	}

	@Override
	public Role delete(String id) {
		Optional<Role> entity = roleRepository.findById(id);
		roleRepository.delete(entity.get());
		return entity.get();
	}

}
