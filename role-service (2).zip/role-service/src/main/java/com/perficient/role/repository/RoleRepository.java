package com.perficient.role.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import com.perficient.role.entity.Role;

public interface RoleRepository
		extends MongoRepository<Role, String>, QuerydslPredicateExecutor<Role> {

	List<Role> findByRoleTitle(String roleTitle);

}
