package com.perficient.role.service;

import org.springframework.stereotype.Component;

import com.perficient.role.entity.QRole;
import com.perficient.role.web.resource.RoleSearch;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;

@Component
public class RoleSearchPredicateBuilder {

	public Predicate createPredicate(RoleSearch projectSearch) {
		QRole qRole = QRole.role;
		BooleanBuilder where = new BooleanBuilder();

		if (projectSearch.getProjectId().isPresent())  {
			where.or(qRole.projectId.eq(projectSearch.getProjectId().get()));
		}

		if (projectSearch.getStartDate().isPresent() && projectSearch.getEndDate().isPresent()) {
			where.or(qRole.startDate.between(projectSearch.getStartDate().get(), projectSearch.getEndDate().get()));
		}

		return where.getValue();
	}

}
