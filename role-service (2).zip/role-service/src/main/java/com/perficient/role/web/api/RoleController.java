package com.perficient.role.web.api;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.perficient.role.entity.Role;
import com.perficient.role.exception.RoleNotFoundException;
import com.perficient.role.service.RoleService;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/roles")
@Slf4j
public class RoleController {

	@Autowired
	private RoleService roleService;

	@GetMapping("/list")
	@ResponseStatus(code = HttpStatus.OK)
	public Mono<List<Role>> list() {
		return Mono.just(roleService.findAllRoles());

	}

	@GetMapping(path = "/{id}")
	@ResponseStatus(code = HttpStatus.OK)
	public Mono<Role> show(@PathVariable("id") String id) {

		Optional<Role> out = roleService.findById(id);

		if (!out.isPresent()) {
        log.debug("unable to find role with id of {}", id);
			throw new RoleNotFoundException("unable to find role");
		}

	 	return Mono.just(out.get());
     
	}
      
	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
//    @RequestMapping(value="/create",method = RequestMethod.POST)
	public Mono<Role> create(@RequestBody Role projResource) {

		return Mono.just(roleService.create(projResource));
	}

	@PutMapping
	@ResponseStatus(code = HttpStatus.OK)
	public Mono<Role> update(@RequestBody Role projResource) {

		return Mono.just(roleService.update(projResource));
	}

	@DeleteMapping(path = "/{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public Role delete(@PathVariable("id") String id) {
		return roleService.delete(id);
	}
	
	
	
    
 
}
