package com.perficient.role.web.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.perficient.role.entity.RoleStatus;
import com.perficient.role.service.RoleStatusService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/role-status")
public class RoleStatusController {

	private RoleStatusService roleStatusService;

	@Autowired
	public RoleStatusController(RoleStatusService roleStatusService) {
		this.roleStatusService = roleStatusService;
	}

	@GetMapping
	@ResponseStatus(code = HttpStatus.OK)
	public Mono<List<RoleStatus>> findAll() {
		return Mono.just(roleStatusService.findAll());
	}
	
	@PostMapping("/create")
	@ResponseStatus(code = HttpStatus.CREATED)
	public Mono<RoleStatus> create(@RequestBody RoleStatus projResource) {

		return Mono.just(roleStatusService.create(projResource));
	}

}
