package com.perficient.role.web.resource;

import java.util.Date;
import java.util.Optional;

import javax.validation.constraints.Min;

import lombok.Data;

@Data
public class RoleSearch {

	private Optional<Long> projectId = Optional.empty();
	
	private Optional<String> roleTitle = Optional.empty();
	
	private Optional<Date> startDate = Optional.empty();
	private Optional<Date> endDate = Optional.empty();

	/* the starting point */
	@Min(value = 1)
	private int pageNumber = 1;

	/* number of records to be returned */
	@Min(value = 1)
	private int size = 1;

	public int getPageNumber() {
		return pageNumber - 1;
	}

}
