package com.perficient.role.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.perficient.role.entity.RoleStatus;
import com.perficient.role.repository.RoleStatusRepository;

@Component
@Transactional
public class RoleStatusServiceImpl implements RoleStatusService {

	@Autowired
	private RoleStatusRepository roleStatusRepository;


	@Override
	public List<RoleStatus> findAll() {
		return roleStatusRepository.findAll();
	}

	@Override
	public RoleStatus create(RoleStatus projResource) {
		return roleStatusRepository.save(projResource);
	}

}
