package com.perficient.role.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.perficient.role.entity.RoleStatus;

public interface RoleStatusRepository extends MongoRepository<RoleStatus, String> {

    
}
