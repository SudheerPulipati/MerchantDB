package com.perficient.role.service;

import java.util.List;
import java.util.Optional;

import com.perficient.role.entity.Role;

public interface RoleService {

	List<Role> findAllRoles();

	Optional<Role> findById(String id);

	Role create(Role projResource);

	Role update(Role resource);

	Role delete(String id);

}
