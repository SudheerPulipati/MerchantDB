package com.perficient.role;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fasterxml.jackson.databind.JsonMappingException;

@SpringBootApplication
public class RoleServiceApplication {

	public static void main(String[] args) throws JsonMappingException {
		SpringApplication.run(RoleServiceApplication.class, args);
	}
}
