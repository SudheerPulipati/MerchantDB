package com.perficient.role.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "role")
public class Role implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    private Long projectId;

    private String roleTitle;

    private Date startDate;

    private Date endDate;

    @DBRef
    private List<RoleStatus> roleStatus;

    private Date resourceStartDate;

    private Integer totalHours;

    private BigDecimal pctDedicate;

    private BigDecimal rate;

    private String comments;

    private String recruitingRequestId;

}
