package com.perficient.role;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.AnnotationConfigWebContextLoader;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.perficient.role.entity.Role;

@ComponentScan("com.perficient.role")
@EnableMongoRepositories(basePackages = "com.perficient.role")
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(loader = AnnotationConfigWebContextLoader.class, classes = { })
public class RoleServiceApplicationTests {

//	@Autowired
//	private RoleRepository roleRepository;
//
//	@Autowired
//	private RoleStatusRepository roleStatusRepository;

	@Autowired
	protected MockMvc mockMvc;

	private ObjectMapper mapper = new ObjectMapper();

	@Test

	public void testAddRole() throws Exception {

		Role flash = new Role();
		
		flash.setId("Test1");
		flash.setProjectId(123L);
		flash.setRate(new BigDecimal(3.5));
		flash.setEndDate(new Date());
		flash.setStartDate(new Date());

		String jsonContent = mapper.writeValueAsString(flash);

		String response = 

				mockMvc.perform(MockMvcRequestBuilders.post("/roles").accept(MediaType.APPLICATION_JSON)

						.contentType(MediaType.APPLICATION_JSON).content(jsonContent))

				.andExpect(MockMvcResultMatchers.status().isCreated()).andReturn().getResponse().getContentAsString();

		// ResponseDTO expected = new ResponseDTO(Status.SUCCESS,
		// MessageConstants.MEMBER_ADDED_SUCCESSFULLY);

		Role receivedResponse = mapper.readValue(response, Role.class);

		System.out.println("response:" + response);
		// Assert.assertThat(receivedResponse,
		// SamePropertyValuesAs.samePropertyValuesAs(expected));

	}
	///////////////////
}
